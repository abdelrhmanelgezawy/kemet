import { Router, type IRouter } from "express";
import { db, alertsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  CreateAlertBody,
  ListZoneAlertsParams,
  ResolveAlertParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  return userId;
}

function serializeAlert(a: typeof alertsTable.$inferSelect) {
  return {
    id: a.id,
    zoneId: a.zoneId,
    zoneName: a.zoneName,
    sensorType: a.sensorType,
    value: parseFloat(a.value),
    minThreshold: a.minThreshold ? parseFloat(a.minThreshold) : null,
    maxThreshold: a.maxThreshold ? parseFloat(a.maxThreshold) : null,
    status: a.status,
    isResolved: a.isResolved,
    createdAt: a.createdAt.toISOString(),
    resolvedAt: a.resolvedAt ? a.resolvedAt.toISOString() : null,
  };
}

router.get("/alerts", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const rows = await db.select().from(alertsTable).where(eq(alertsTable.isResolved, false));
  res.json(rows.map(serializeAlert));
});

router.post("/alerts", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = CreateAlertBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [alert] = await db.insert(alertsTable).values({
    zoneId: parsed.data.zoneId,
    zoneName: parsed.data.zoneName,
    sensorType: parsed.data.sensorType,
    value: parsed.data.value.toString(),
    minThreshold: parsed.data.minThreshold != null ? parsed.data.minThreshold.toString() : null,
    maxThreshold: parsed.data.maxThreshold != null ? parsed.data.maxThreshold.toString() : null,
    status: parsed.data.status,
    isResolved: false,
  }).returning();

  res.status(201).json(serializeAlert(alert));
});

router.get("/zones/:id/alerts", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = ListZoneAlertsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const rows = await db.select().from(alertsTable).where(eq(alertsTable.zoneId, params.data.id));
  res.json(rows.map(serializeAlert));
});

router.patch("/alerts/:id/resolve", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = ResolveAlertParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [alert] = await db.update(alertsTable)
    .set({ isResolved: true, resolvedAt: new Date() })
    .where(eq(alertsTable.id, params.data.id))
    .returning();

  if (!alert) {
    res.status(404).json({ error: "Alert not found" });
    return;
  }

  res.json(serializeAlert(alert));
});

export default router;
