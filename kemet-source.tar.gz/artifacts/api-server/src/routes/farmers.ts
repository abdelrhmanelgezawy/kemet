import { Router, type IRouter } from "express";
import { db, usersTable, farmerRequestsTable, zoneAssignmentsTable, zonesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  ApproveFarmerRequestParams,
  RejectFarmerRequestParams,
  RejectFarmerRequestBody,
  CreateFarmerRequestBody,
  ListFarmerZonesParams,
  AssignFarmerZoneParams,
  AssignFarmerZoneBody,
  RemoveFarmerZoneParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  return userId;
}

function serializeFarmer(u: typeof usersTable.$inferSelect) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    status: u.status,
    createdAt: u.createdAt.toISOString(),
    assignedOwnerId: u.assignedOwnerId ?? null,
  };
}

function serializeRequest(r: typeof farmerRequestsTable.$inferSelect, farmer?: typeof usersTable.$inferSelect) {
  return {
    id: r.id,
    farmerId: r.farmerId,
    ownerId: r.ownerId,
    status: r.status,
    rejectionReason: r.rejectionReason ?? null,
    createdAt: r.createdAt.toISOString(),
    respondedAt: r.respondedAt ? r.respondedAt.toISOString() : null,
    farmer: farmer ? serializeFarmer(farmer) : undefined,
  };
}

// List farmers managed by this owner
router.get("/farmers", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const rows = await db.select().from(usersTable)
    .where(and(eq(usersTable.role, "farmer"), eq(usersTable.assignedOwnerId, userId)));
  res.json(rows.map(serializeFarmer));
});

// Farmer requests
router.get("/farmer-requests", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const requests = await db.select().from(farmerRequestsTable)
    .where(and(eq(farmerRequestsTable.ownerId, userId), eq(farmerRequestsTable.status, "pending")));

  const result = await Promise.all(requests.map(async (r) => {
    const [farmer] = await db.select().from(usersTable).where(eq(usersTable.id, r.farmerId)).limit(1);
    return serializeRequest(r, farmer);
  }));

  res.json(result);
});

router.post("/farmer-requests", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = CreateFarmerRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [request] = await db.insert(farmerRequestsTable).values({
    farmerId: userId,
    ownerId: parsed.data.ownerId,
    status: "pending",
  }).returning();

  res.status(201).json(serializeRequest(request));
});

router.patch("/farmer-requests/:id/approve", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = ApproveFarmerRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db.select().from(farmerRequestsTable)
    .where(eq(farmerRequestsTable.id, params.data.id)).limit(1);
  if (!existing) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  const [request] = await db.update(farmerRequestsTable).set({
    status: "approved",
    respondedAt: new Date(),
  }).where(eq(farmerRequestsTable.id, params.data.id)).returning();

  // Update farmer's assignedOwnerId
  await db.update(usersTable)
    .set({ assignedOwnerId: userId, status: "approved" })
    .where(eq(usersTable.id, existing.farmerId));

  res.json(serializeRequest(request));
});

router.patch("/farmer-requests/:id/reject", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = RejectFarmerRequestParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = RejectFarmerRequestBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [request] = await db.update(farmerRequestsTable).set({
    status: "rejected",
    rejectionReason: parsed.data.reason ?? null,
    respondedAt: new Date(),
  }).where(eq(farmerRequestsTable.id, params.data.id)).returning();

  if (!request) {
    res.status(404).json({ error: "Request not found" });
    return;
  }

  res.json(serializeRequest(request));
});

// Zone assignments for farmers
router.get("/farmers/:farmerId/zones", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = ListFarmerZonesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const assignments = await db.select().from(zoneAssignmentsTable)
    .where(eq(zoneAssignmentsTable.farmerId, params.data.farmerId));

  const zones = await Promise.all(assignments.map(async (a) => {
    const [zone] = await db.select().from(zonesTable).where(eq(zonesTable.id, a.zoneId)).limit(1);
    return zone;
  }));

  res.json(zones.filter(Boolean).map(z => ({
    id: z!.id,
    ownerId: z!.ownerId,
    cropName: z!.cropName,
    iconCode: z!.iconCode,
    location: z!.location,
    cropProfile: z!.cropProfile,
    mode: z!.mode,
    createdAt: z!.createdAt.toISOString(),
    updatedAt: z!.updatedAt.toISOString(),
  })));
});

router.post("/farmers/:farmerId/zones", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = AssignFarmerZoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = AssignFarmerZoneBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  await db.insert(zoneAssignmentsTable).values({
    farmerId: params.data.farmerId,
    zoneId: parsed.data.zoneId,
  });

  res.status(201).json({ success: true });
});

router.delete("/farmers/:farmerId/zones/:zoneId", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = RemoveFarmerZoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db.delete(zoneAssignmentsTable).where(
    and(
      eq(zoneAssignmentsTable.farmerId, params.data.farmerId),
      eq(zoneAssignmentsTable.zoneId, params.data.zoneId),
    )
  );

  res.sendStatus(204);
});

export default router;
