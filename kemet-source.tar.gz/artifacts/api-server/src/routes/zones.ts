import { Router, type IRouter } from "express";
import { db, zonesTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  GetZoneParams,
  UpdateZoneParams,
  DeleteZoneParams,
  CreateZoneBody,
  UpdateZoneBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  return userId;
}

function serializeZone(z: typeof zonesTable.$inferSelect) {
  return {
    id: z.id,
    ownerId: z.ownerId,
    cropName: z.cropName,
    iconCode: z.iconCode,
    location: z.location,
    cropProfile: z.cropProfile,
    mode: z.mode,
    createdAt: z.createdAt.toISOString(),
    updatedAt: z.updatedAt.toISOString(),
  };
}

router.get("/zones", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const rows = await db.select().from(zonesTable).where(eq(zonesTable.ownerId, userId));
  res.json(rows.map(serializeZone));
});

router.post("/zones", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = CreateZoneBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [zone] = await db.insert(zonesTable).values({
    ownerId: userId,
    cropName: parsed.data.cropName,
    iconCode: parsed.data.iconCode,
    location: parsed.data.location,
    cropProfile: parsed.data.cropProfile ?? {},
    mode: parsed.data.mode ?? {},
  }).returning();

  res.status(201).json(serializeZone(zone));
});

router.get("/zones/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = GetZoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [zone] = await db.select().from(zonesTable).where(eq(zonesTable.id, params.data.id)).limit(1);
  if (!zone) {
    res.status(404).json({ error: "Zone not found" });
    return;
  }

  if (zone.ownerId !== userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  res.json(serializeZone(zone));
});

router.patch("/zones/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = UpdateZoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateZoneBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db.select().from(zonesTable).where(eq(zonesTable.id, params.data.id)).limit(1);
  if (!existing) {
    res.status(404).json({ error: "Zone not found" });
    return;
  }
  if (existing.ownerId !== userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const updates: Partial<typeof zonesTable.$inferInsert> = {};
  if (parsed.data.cropName !== undefined) updates.cropName = parsed.data.cropName;
  if (parsed.data.location !== undefined) updates.location = parsed.data.location;
  if (parsed.data.cropProfile !== undefined) updates.cropProfile = parsed.data.cropProfile;
  if (parsed.data.mode !== undefined) updates.mode = parsed.data.mode;

  const [zone] = await db.update(zonesTable).set(updates).where(eq(zonesTable.id, params.data.id)).returning();
  res.json(serializeZone(zone));
});

router.delete("/zones/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = DeleteZoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [existing] = await db.select().from(zonesTable).where(eq(zonesTable.id, params.data.id)).limit(1);
  if (!existing) {
    res.status(404).json({ error: "Zone not found" });
    return;
  }
  if (existing.ownerId !== userId) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  await db.delete(zonesTable).where(eq(zonesTable.id, params.data.id));
  res.sendStatus(204);
});

export default router;
