import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import zonesRouter from "./zones";
import sensorsRouter from "./sensors";
import alertsRouter from "./alerts";
import analyticsRouter from "./analytics";
import farmersRouter from "./farmers";
import notificationsRouter from "./notifications";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(zonesRouter);
router.use(sensorsRouter);
router.use(alertsRouter);
router.use(analyticsRouter);
router.use(farmersRouter);
router.use(notificationsRouter);

export default router;
