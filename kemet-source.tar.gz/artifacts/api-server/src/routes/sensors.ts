import { Router, type IRouter } from "express";
import { db, sensorsTable, sensorLogsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  ListSensorsParams,
  CreateSensorParams,
  CreateSensorBody,
  UpdateSensorParams,
  UpdateSensorBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  return userId;
}

function serializeSensor(s: typeof sensorsTable.$inferSelect) {
  return {
    id: s.id,
    zoneId: s.zoneId,
    sensorType: s.sensorType,
    value: parseFloat(s.value),
    status: s.status,
    lastUpdate: s.lastUpdate.toISOString(),
    createdAt: s.createdAt.toISOString(),
  };
}

router.get("/zones/:id/sensors", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = ListSensorsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const rows = await db.select().from(sensorsTable).where(eq(sensorsTable.zoneId, params.data.id));
  res.json(rows.map(serializeSensor));
});

router.post("/zones/:id/sensors", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = CreateSensorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = CreateSensorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [sensor] = await db.insert(sensorsTable).values({
    zoneId: params.data.id,
    sensorType: parsed.data.sensorType,
    value: parsed.data.value.toString(),
    status: parsed.data.status,
    lastUpdate: new Date(),
  }).returning();

  // Also log to sensor_logs for history
  await db.insert(sensorLogsTable).values({
    zoneId: params.data.id,
    sensorType: parsed.data.sensorType,
    value: parsed.data.value.toString(),
    timestamp: new Date(),
  });

  res.status(201).json(serializeSensor(sensor));
});

router.patch("/sensors/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = UpdateSensorParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateSensorBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Partial<typeof sensorsTable.$inferInsert> = {
    lastUpdate: new Date(),
  };
  if (parsed.data.value !== undefined) updates.value = parsed.data.value.toString();
  if (parsed.data.status !== undefined) updates.status = parsed.data.status;

  const [sensor] = await db.update(sensorsTable).set(updates).where(eq(sensorsTable.id, params.data.id)).returning();
  if (!sensor) {
    res.status(404).json({ error: "Sensor not found" });
    return;
  }

  // Log updated value
  if (parsed.data.value !== undefined) {
    await db.insert(sensorLogsTable).values({
      zoneId: sensor.zoneId,
      sensorType: sensor.sensorType,
      value: sensor.value,
      timestamp: new Date(),
    });
  }

  res.json(serializeSensor(sensor));
});

export default router;
