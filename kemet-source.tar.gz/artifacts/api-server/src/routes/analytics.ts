import { Router, type IRouter } from "express";
import { db, sensorLogsTable, alertsTable, sensorsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import {
  GetSensorLogsParams,
  GetZoneSummaryParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return null;
  }
  return userId;
}

router.get("/zones/:id/sensor-logs", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = GetSensorLogsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const rows = await db.select().from(sensorLogsTable)
    .where(eq(sensorLogsTable.zoneId, params.data.id))
    .limit(200);

  res.json(rows.map(r => ({
    id: r.id,
    zoneId: r.zoneId,
    sensorType: r.sensorType,
    value: parseFloat(r.value),
    timestamp: r.timestamp.toISOString(),
  })));
});

router.get("/zones/:id/summary", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const params = GetZoneSummaryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const zoneId = params.data.id;
  const [allAlerts, unresolvedAlerts, latestSensors] = await Promise.all([
    db.select().from(alertsTable).where(eq(alertsTable.zoneId, zoneId)),
    db.select().from(alertsTable).where(and(eq(alertsTable.zoneId, zoneId), eq(alertsTable.isResolved, false))),
    db.select().from(sensorsTable).where(eq(sensorsTable.zoneId, zoneId)),
  ]);

  res.json({
    zoneId,
    totalAlerts: allAlerts.length,
    unresolvedAlerts: unresolvedAlerts.length,
    sensorCount: latestSensors.length,
    latestReadings: latestSensors.map(s => ({
      id: s.id,
      zoneId: s.zoneId,
      sensorType: s.sensorType,
      value: parseFloat(s.value),
      status: s.status,
      lastUpdate: s.lastUpdate.toISOString(),
      createdAt: s.createdAt.toISOString(),
    })),
  });
});

export default router;
