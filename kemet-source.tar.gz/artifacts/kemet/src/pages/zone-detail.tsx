import { useState } from "react";
import { useLocation } from "wouter";
import {
  useGetZone, getGetZoneQueryKey,
  useListSensors, getListSensorsQueryKey,
  useListZoneAlerts, getListZoneAlertsQueryKey,
  useGetSensorLogs, getGetSensorLogsQueryKey,
  useGetZoneSummary, getGetZoneSummaryQueryKey,
  useResolveAlert,
  useUpdateZone,
  useDeleteZone,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, AlertTriangle, Activity, Thermometer, Droplets, Zap, Wind, CheckCircle, Trash2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const SENSOR_ICONS: Record<string, typeof Activity> = {
  temperature: Thermometer,
  moisture: Droplets,
  ec: Zap,
  humidity: Wind,
};

const SENSOR_COLORS = ["#00c47a", "#22d3ee", "#facc15", "#a78bfa"];

function SensorCard({ sensor }: { sensor: any }) {
  const Icon = SENSOR_ICONS[sensor.sensorType?.toLowerCase()] ?? Activity;
  const statusColor = sensor.status === "NORMAL" ? "text-primary border-primary/20" : sensor.status === "HIGH" ? "text-yellow-400 border-yellow-400/20" : "text-red-400 border-red-400/20";
  return (
    <div data-testid={`card-sensor-${sensor.id}`} className={`border bg-card p-4 ${statusColor}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4" />
        <span className="font-mono text-xs uppercase tracking-wider">{sensor.sensorType}</span>
      </div>
      <div className="font-mono text-2xl font-bold">{Number(sensor.value).toFixed(1)}</div>
      <div className="font-mono text-xs mt-1 opacity-70">{sensor.status}</div>
    </div>
  );
}

function AlertRow({ alert, onResolve }: { alert: any; onResolve: () => void }) {
  const resolve = useResolveAlert();
  const { toast } = useToast();

  const handleResolve = () => {
    resolve.mutate({ id: alert.id }, {
      onSuccess: () => { toast({ title: "Alert resolved" }); onResolve(); },
      onError: () => toast({ title: "Failed to resolve", variant: "destructive" }),
    });
  };

  return (
    <div data-testid={`alert-row-${alert.id}`} className="flex items-center justify-between px-4 py-3 border-b border-border last:border-0">
      <div>
        <span className="font-mono text-xs text-muted-foreground uppercase">{alert.sensorType}: </span>
        <span className={`font-mono text-xs ${alert.status === "HIGH" ? "text-yellow-400" : "text-red-400"}`}>
          {alert.status} ({Number(alert.value).toFixed(1)})
        </span>
        {alert.isResolved && <span className="ml-2 font-mono text-xs text-primary">[RESOLVED]</span>}
      </div>
      {!alert.isResolved && (
        <Button
          data-testid={`button-resolve-alert-${alert.id}`}
          variant="outline"
          size="sm"
          className="font-mono text-xs rounded-none h-7"
          onClick={handleResolve}
          disabled={resolve.isPending}
        >
          <CheckCircle className="w-3 h-3 mr-1" /> Resolve
        </Button>
      )}
    </div>
  );
}

export default function ZoneDetailPage({ id }: { id: number }) {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: zone, isLoading: zoneLoading } = useGetZone(id, {
    query: { queryKey: getGetZoneQueryKey(id), enabled: !!id }
  });
  const { data: sensors } = useListSensors(id, {
    query: { queryKey: getListSensorsQueryKey(id), enabled: !!id }
  });
  const { data: alerts, refetch: refetchAlerts } = useListZoneAlerts(id, {
    query: { queryKey: getListZoneAlertsQueryKey(id), enabled: !!id }
  });
  const { data: logs } = useGetSensorLogs(id, {
    query: { queryKey: getGetSensorLogsQueryKey(id), enabled: !!id }
  });

  const deleteZone = useDeleteZone();

  const handleDelete = () => {
    if (!confirm("Delete this zone? This cannot be undone.")) return;
    deleteZone.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Zone deleted" });
        setLocation("/zones");
      },
      onError: () => toast({ title: "Failed to delete", variant: "destructive" }),
    });
  };

  // Build chart data grouped by timestamp
  const chartData: Record<string, any> = {};
  const sensorTypes = [...new Set(logs?.map(l => l.sensorType) ?? [])];
  logs?.forEach(log => {
    const ts = new Date(log.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    if (!chartData[ts]) chartData[ts] = { ts };
    chartData[ts][log.sensorType] = Number(log.value);
  });
  const chartRows = Object.values(chartData).slice(-50);

  if (zoneLoading) {
    return (
      <div className="space-y-4">
        <div className="h-8 w-48 bg-card border border-border animate-pulse" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-24 bg-card border border-border animate-pulse" />)}
        </div>
      </div>
    );
  }

  if (!zone) return <div className="font-mono text-muted-foreground">Zone not found.</div>;

  const profile = zone.cropProfile as any ?? {};
  const unresolvedAlerts = alerts?.filter((a: any) => !a.isResolved) ?? [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <button
            data-testid="button-back"
            onClick={() => setLocation("/zones")}
            className="flex items-center gap-1 font-mono text-xs text-muted-foreground hover:text-primary mb-3 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" /> Back to Zones
          </button>
          <h2 className="font-mono text-2xl font-bold">{zone.cropName}</h2>
          <div className="font-mono text-xs text-muted-foreground mt-1">{zone.location ?? "—"}</div>
        </div>
        <div className="flex items-center gap-2">
          {unresolvedAlerts.length > 0 && (
            <div className="flex items-center gap-1 text-yellow-400 font-mono text-xs border border-yellow-400/30 px-3 py-1.5">
              <AlertTriangle className="w-3 h-3" />
              {unresolvedAlerts.length} ALERT{unresolvedAlerts.length > 1 ? "S" : ""}
            </div>
          )}
          <Button
            data-testid="button-delete-zone"
            variant="outline"
            size="sm"
            className="font-mono text-xs rounded-none border-red-400/30 text-red-400 hover:bg-red-400/10"
            onClick={handleDelete}
            disabled={deleteZone.isPending}
          >
            <Trash2 className="w-3 h-3 mr-1" /> Delete
          </Button>
        </div>
      </div>

      {/* Sensor Readings */}
      <div>
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">Live Readings</h3>
        {sensors && sensors.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {sensors.map((s: any) => <SensorCard key={s.id} sensor={s} />)}
          </div>
        ) : (
          <div className="border border-dashed border-border p-8 text-center">
            <Activity className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
            <p className="font-mono text-xs text-muted-foreground">No sensors configured for this zone.</p>
          </div>
        )}
      </div>

      {/* Crop Profile Thresholds */}
      {Object.keys(profile).length > 0 && (
        <div>
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">Crop Thresholds</h3>
          <div className="border border-border bg-card divide-y divide-border">
            {Object.entries(profile).map(([key, val]) => (
              <div key={key} className="flex items-center justify-between px-5 py-3">
                <span className="font-mono text-xs text-muted-foreground uppercase">{key.replace(/_/g, " ")}</span>
                <span className="font-mono text-xs text-foreground">{String(val)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sensor History Chart */}
      {chartRows.length > 0 && (
        <div>
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">Sensor History</h3>
          <div className="border border-border bg-card p-4">
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={chartRows}>
                <XAxis dataKey="ts" tick={{ fontSize: 10, fontFamily: "monospace" }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 10, fontFamily: "monospace" }} tickLine={false} axisLine={false} width={35} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 0, fontFamily: "monospace", fontSize: 11 }}
                  labelStyle={{ color: "hsl(var(--muted-foreground))" }}
                />
                <Legend wrapperStyle={{ fontFamily: "monospace", fontSize: 11 }} />
                {sensorTypes.map((type, i) => (
                  <Line
                    key={type}
                    type="monotone"
                    dataKey={type}
                    stroke={SENSOR_COLORS[i % SENSOR_COLORS.length]}
                    dot={false}
                    strokeWidth={2}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Alerts */}
      <div>
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">Zone Alerts</h3>
        {alerts && alerts.length > 0 ? (
          <div className="border border-border bg-card">
            {alerts.map((a: any) => (
              <AlertRow
                key={a.id}
                alert={a}
                onResolve={() => {
                  queryClient.invalidateQueries({ queryKey: getListZoneAlertsQueryKey(id) });
                  queryClient.invalidateQueries({ queryKey: getGetZoneSummaryQueryKey(id) });
                }}
              />
            ))}
          </div>
        ) : (
          <div className="border border-dashed border-border p-8 text-center">
            <CheckCircle className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="font-mono text-xs text-muted-foreground">No alerts for this zone.</p>
          </div>
        )}
      </div>
    </div>
  );
}
