import { useLocation } from "wouter";
import { useListZones, useListAlerts, useGetZoneSummary, getGetZoneSummaryQueryKey } from "@workspace/api-client-react";
import { Activity, AlertTriangle, Map, Sprout, Thermometer, Droplets, Zap, Wind } from "lucide-react";

function SensorBadge({ type, value, status }: { type: string; value: number; status: string }) {
  const statusColor = status === "NORMAL" ? "text-primary" : status === "HIGH" ? "text-yellow-400" : "text-red-400";
  const icons: Record<string, typeof Thermometer> = {
    temperature: Thermometer,
    moisture: Droplets,
    ec: Zap,
    humidity: Wind,
  };
  const Icon = icons[type.toLowerCase()] ?? Activity;
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-mono ${statusColor}`}>
      <Icon className="w-3 h-3" />
      {value.toFixed(1)}
    </span>
  );
}

function ZoneCard({ zone }: { zone: any }) {
  const [, setLocation] = useLocation();
  const { data: summary } = useGetZoneSummary(zone.id, {
    query: { queryKey: getGetZoneSummaryQueryKey(zone.id) }
  });

  const hasAlerts = summary && summary.unresolvedAlerts > 0;

  return (
    <div
      data-testid={`card-zone-${zone.id}`}
      onClick={() => setLocation(`/zones/${zone.id}`)}
      className="border border-border bg-card hover:border-primary/50 hover:bg-accent/20 transition-all cursor-pointer group p-5"
    >
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">{zone.location ?? "—"}</div>
          <h3 className="font-mono font-bold text-foreground text-sm group-hover:text-primary transition-colors">{zone.cropName}</h3>
        </div>
        {hasAlerts && (
          <div className="flex items-center gap-1 text-yellow-400">
            <AlertTriangle className="w-4 h-4" />
            <span className="font-mono text-xs">{summary.unresolvedAlerts}</span>
          </div>
        )}
      </div>

      {summary && summary.latestReadings.length > 0 ? (
        <div className="grid grid-cols-2 gap-2 mt-3">
          {summary.latestReadings.slice(0, 4).map((r: any) => (
            <SensorBadge key={r.id} type={r.sensorType} value={r.value} status={r.status} />
          ))}
        </div>
      ) : (
        <div className="text-xs font-mono text-muted-foreground mt-3">No sensors</div>
      )}

      <div className="mt-4 flex items-center justify-between">
        <span className={`text-xs font-mono px-2 py-0.5 border ${hasAlerts ? "border-yellow-400/30 text-yellow-400 bg-yellow-400/5" : "border-primary/30 text-primary bg-primary/5"}`}>
          {hasAlerts ? "ALERT" : "NOMINAL"}
        </span>
        <span className="text-xs font-mono text-muted-foreground">{summary?.sensorCount ?? 0} sensors</span>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { data: zones, isLoading: zonesLoading } = useListZones();
  const { data: alerts, isLoading: alertsLoading } = useListAlerts();

  const totalZones = zones?.length ?? 0;
  const activeAlerts = alerts?.length ?? 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Kemet Command</h1>
        <h2 className="font-mono text-2xl font-bold text-foreground">Dashboard</h2>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div data-testid="stat-zones" className="border border-border bg-card p-5">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Map className="w-4 h-4" />
            <span className="font-mono text-xs uppercase tracking-wider">Zones</span>
          </div>
          <div className="font-mono text-3xl font-bold text-foreground">{zonesLoading ? "—" : totalZones}</div>
        </div>
        <div data-testid="stat-alerts" className="border border-border bg-card p-5">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <AlertTriangle className="w-4 h-4" />
            <span className="font-mono text-xs uppercase tracking-wider">Active Alerts</span>
          </div>
          <div className={`font-mono text-3xl font-bold ${activeAlerts > 0 ? "text-yellow-400" : "text-foreground"}`}>
            {alertsLoading ? "—" : activeAlerts}
          </div>
        </div>
        <div data-testid="stat-sensors" className="border border-border bg-card p-5">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Activity className="w-4 h-4" />
            <span className="font-mono text-xs uppercase tracking-wider">Monitoring</span>
          </div>
          <div className="font-mono text-3xl font-bold text-primary">LIVE</div>
        </div>
        <div data-testid="stat-crops" className="border border-border bg-card p-5">
          <div className="flex items-center gap-2 text-muted-foreground mb-3">
            <Sprout className="w-4 h-4" />
            <span className="font-mono text-xs uppercase tracking-wider">Crops</span>
          </div>
          <div className="font-mono text-3xl font-bold text-foreground">{zonesLoading ? "—" : totalZones}</div>
        </div>
      </div>

      {/* Zone Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider">Active Zones</h3>
        </div>
        {zonesLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1,2,3].map(i => <div key={i} className="border border-border bg-card p-5 h-32 animate-pulse" />)}
          </div>
        ) : zones && zones.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {zones.map(zone => <ZoneCard key={zone.id} zone={zone} />)}
          </div>
        ) : (
          <div className="border border-dashed border-border p-12 text-center">
            <Sprout className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
            <p className="font-mono text-sm text-muted-foreground">No zones configured.</p>
            <p className="font-mono text-xs text-muted-foreground mt-1">Go to Zones to add your first crop zone.</p>
          </div>
        )}
      </div>

      {/* Recent Alerts */}
      {activeAlerts > 0 && (
        <div>
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-4">Active Alerts</h3>
          <div className="border border-border bg-card divide-y divide-border">
            {alerts!.slice(0, 5).map((alert: any) => (
              <div key={alert.id} data-testid={`alert-item-${alert.id}`} className="flex items-center justify-between px-5 py-3">
                <div>
                  <span className="font-mono text-xs text-muted-foreground uppercase">{alert.sensorType} — </span>
                  <span className="font-mono text-xs text-foreground">{alert.zoneName}</span>
                </div>
                <span className={`font-mono text-xs px-2 py-0.5 border ${alert.status === "HIGH" ? "border-yellow-400/30 text-yellow-400" : "border-red-400/30 text-red-400"}`}>
                  {alert.status}: {alert.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
