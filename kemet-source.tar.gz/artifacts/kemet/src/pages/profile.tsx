import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useLogout, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { LogOut, User, Mail, Shield, Calendar } from "lucide-react";

export default function ProfilePage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const logout = useLogout();

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.setQueryData(getGetMeQueryKey(), null);
        setLocation("/login");
      },
      onError: () => toast({ title: "Logout failed", variant: "destructive" }),
    });
  };

  if (!user) return null;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Account</h1>
        <h2 className="font-mono text-2xl font-bold">Profile</h2>
      </div>

      <div className="border border-border bg-card max-w-lg">
        <div className="border-b border-border px-6 py-4">
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Operator Profile</div>
          <div className="font-mono text-lg font-bold text-foreground">{user.name}</div>
        </div>

        <div className="divide-y divide-border">
          <div className="flex items-center gap-4 px-6 py-4">
            <User className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div>
              <div className="font-mono text-xs text-muted-foreground uppercase">Name</div>
              <div className="font-mono text-sm text-foreground mt-0.5">{user.name}</div>
            </div>
          </div>
          <div className="flex items-center gap-4 px-6 py-4">
            <Mail className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div>
              <div className="font-mono text-xs text-muted-foreground uppercase">Email</div>
              <div className="font-mono text-sm text-foreground mt-0.5">{user.email}</div>
            </div>
          </div>
          <div className="flex items-center gap-4 px-6 py-4">
            <Shield className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div>
              <div className="font-mono text-xs text-muted-foreground uppercase">Role</div>
              <div className="font-mono text-sm text-primary mt-0.5 uppercase">{user.role}</div>
            </div>
          </div>
          <div className="flex items-center gap-4 px-6 py-4">
            <Calendar className="w-4 h-4 text-muted-foreground flex-shrink-0" />
            <div>
              <div className="font-mono text-xs text-muted-foreground uppercase">Joined</div>
              <div className="font-mono text-sm text-foreground mt-0.5">
                {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : "—"}
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-border">
          <Button
            data-testid="button-logout"
            variant="outline"
            className="font-mono uppercase tracking-wider rounded-none border-red-400/30 text-red-400 hover:bg-red-400/10 hover:text-red-400"
            onClick={handleLogout}
            disabled={logout.isPending}
          >
            <LogOut className="w-4 h-4 mr-2" />
            {logout.isPending ? "Disconnecting..." : "Disconnect"}
          </Button>
        </div>
      </div>
    </div>
  );
}
