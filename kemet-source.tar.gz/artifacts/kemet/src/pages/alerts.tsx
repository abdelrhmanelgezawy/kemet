import { useListAlerts, getListAlertsQueryKey, useResolveAlert } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, CheckCircle, ShieldCheck } from "lucide-react";

export default function AlertsPage() {
  const { data: alerts, isLoading } = useListAlerts();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const resolve = useResolveAlert();

  const handleResolve = (id: number) => {
    resolve.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Alert resolved" });
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      },
      onError: () => toast({ title: "Failed to resolve", variant: "destructive" }),
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Monitoring</h1>
        <h2 className="font-mono text-2xl font-bold">Active Alerts</h2>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-16 bg-card border border-border animate-pulse" />)}
        </div>
      ) : alerts && alerts.length > 0 ? (
        <div className="border border-border bg-card divide-y divide-border">
          {alerts.map((alert: any) => (
            <div
              key={alert.id}
              data-testid={`alert-row-${alert.id}`}
              className="flex items-center justify-between px-5 py-4"
            >
              <div className="flex items-center gap-4">
                <AlertTriangle className={`w-5 h-5 ${alert.status === "HIGH" ? "text-yellow-400" : "text-red-400"}`} />
                <div>
                  <div className="font-mono text-sm font-bold text-foreground">{alert.zoneName}</div>
                  <div className="font-mono text-xs text-muted-foreground mt-0.5">
                    <span className="uppercase">{alert.sensorType}</span>
                    {" · "}
                    Value: {Number(alert.value).toFixed(1)}
                    {alert.minThreshold != null && ` · Min: ${Number(alert.minThreshold).toFixed(1)}`}
                    {alert.maxThreshold != null && ` · Max: ${Number(alert.maxThreshold).toFixed(1)}`}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className={`font-mono text-xs px-2 py-0.5 border ${alert.status === "HIGH" ? "border-yellow-400/30 text-yellow-400 bg-yellow-400/5" : "border-red-400/30 text-red-400 bg-red-400/5"}`}>
                  {alert.status}
                </span>
                <Button
                  data-testid={`button-resolve-${alert.id}`}
                  variant="outline"
                  size="sm"
                  className="font-mono text-xs rounded-none h-7"
                  onClick={() => handleResolve(alert.id)}
                  disabled={resolve.isPending}
                >
                  <CheckCircle className="w-3 h-3 mr-1" /> Resolve
                </Button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="border border-dashed border-border p-16 text-center">
          <ShieldCheck className="w-10 h-10 text-primary mx-auto mb-4" />
          <p className="font-mono text-sm text-foreground font-bold">All clear</p>
          <p className="font-mono text-xs text-muted-foreground mt-1">No active alerts across all zones.</p>
        </div>
      )}
    </div>
  );
}
