import { useState } from "react";
import { useLocation } from "wouter";
import { useLogin, useRegister, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Activity } from "lucide-react";

export default function LoginPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [regForm, setRegForm] = useState({ name: "", email: "", password: "" });

  const login = useLogin();
  const register = useRegister();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    login.mutate({ data: loginForm }, {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        setLocation("/dashboard");
      },
      onError: (err: any) => {
        toast({ title: "Login failed", description: err?.data?.error ?? "Invalid credentials", variant: "destructive" });
      },
    });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    register.mutate({ data: regForm }, {
      onSuccess: () => {
        toast({ title: "Account created", description: "You can now log in." });
        setMode("login");
        setLoginForm({ email: regForm.email, password: regForm.password });
      },
      onError: (err: any) => {
        toast({ title: "Registration failed", description: err?.data?.error ?? "An error occurred", variant: "destructive" });
      },
    });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center dark">
      <div className="w-full max-w-sm px-6">
        <div className="mb-10 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Activity className="w-6 h-6 text-primary" />
            <span className="font-mono font-bold text-xl text-primary tracking-widest uppercase">Kemet</span>
          </div>
          <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider">Smart Farm Command Center</p>
        </div>

        <div className="border border-border bg-card p-8">
          <div className="flex mb-8">
            <button
              data-testid="tab-login"
              onClick={() => setMode("login")}
              className={`flex-1 pb-2 font-mono text-xs uppercase tracking-wider border-b-2 transition-colors ${mode === "login" ? "border-primary text-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
            >
              Login
            </button>
            <button
              data-testid="tab-register"
              onClick={() => setMode("register")}
              className={`flex-1 pb-2 font-mono text-xs uppercase tracking-wider border-b-2 transition-colors ${mode === "register" ? "border-primary text-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
            >
              Register
            </button>
          </div>

          {mode === "login" ? (
            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <Label htmlFor="login-email" className="font-mono text-xs text-muted-foreground uppercase">Email</Label>
                <Input
                  id="login-email"
                  data-testid="input-email"
                  type="email"
                  value={loginForm.email}
                  onChange={(e) => setLoginForm(f => ({ ...f, email: e.target.value }))}
                  required
                  className="mt-1 font-mono rounded-none border-border bg-input"
                />
              </div>
              <div>
                <Label htmlFor="login-password" className="font-mono text-xs text-muted-foreground uppercase">Password</Label>
                <Input
                  id="login-password"
                  data-testid="input-password"
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm(f => ({ ...f, password: e.target.value }))}
                  required
                  className="mt-1 font-mono rounded-none border-border bg-input"
                />
              </div>
              <Button
                data-testid="button-login"
                type="submit"
                className="w-full font-mono uppercase tracking-wider rounded-none"
                disabled={login.isPending}
              >
                {login.isPending ? "Authenticating..." : "Login"}
              </Button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-5">
              <div>
                <Label htmlFor="reg-name" className="font-mono text-xs text-muted-foreground uppercase">Name</Label>
                <Input
                  id="reg-name"
                  data-testid="input-name"
                  value={regForm.name}
                  onChange={(e) => setRegForm(f => ({ ...f, name: e.target.value }))}
                  required
                  className="mt-1 font-mono rounded-none border-border bg-input"
                />
              </div>
              <div>
                <Label htmlFor="reg-email" className="font-mono text-xs text-muted-foreground uppercase">Email</Label>
                <Input
                  id="reg-email"
                  data-testid="input-reg-email"
                  type="email"
                  value={regForm.email}
                  onChange={(e) => setRegForm(f => ({ ...f, email: e.target.value }))}
                  required
                  className="mt-1 font-mono rounded-none border-border bg-input"
                />
              </div>
              <div>
                <Label htmlFor="reg-password" className="font-mono text-xs text-muted-foreground uppercase">Password</Label>
                <Input
                  id="reg-password"
                  data-testid="input-reg-password"
                  type="password"
                  value={regForm.password}
                  onChange={(e) => setRegForm(f => ({ ...f, password: e.target.value }))}
                  required
                  minLength={6}
                  className="mt-1 font-mono rounded-none border-border bg-input"
                />
              </div>
              <Button
                data-testid="button-register"
                type="submit"
                className="w-full font-mono uppercase tracking-wider rounded-none"
                disabled={register.isPending}
              >
                {register.isPending ? "Creating account..." : "Create Account"}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
