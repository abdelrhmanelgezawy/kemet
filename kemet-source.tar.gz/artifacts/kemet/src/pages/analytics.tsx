import { useListZones, useListAlerts, useListSensors, getListSensorsQueryKey } from "@workspace/api-client-react";
import { Activity, AlertTriangle, Map, Thermometer, Droplets, Zap, Wind } from "lucide-react";

const SENSOR_ICONS: Record<string, typeof Activity> = {
  temperature: Thermometer,
  moisture: Droplets,
  ec: Zap,
  humidity: Wind,
};

function StatBlock({ label, value, sub, color = "text-foreground" }: { label: string; value: string | number; sub?: string; color?: string }) {
  return (
    <div className="border border-border bg-card p-5">
      <div className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3">{label}</div>
      <div className={`font-mono text-3xl font-bold ${color}`}>{value}</div>
      {sub && <div className="font-mono text-xs text-muted-foreground mt-1">{sub}</div>}
    </div>
  );
}

export default function AnalyticsPage() {
  const { data: zones, isLoading: zonesLoading } = useListZones();
  const { data: alerts, isLoading: alertsLoading } = useListAlerts();

  const totalZones = zones?.length ?? 0;
  const totalAlerts = alerts?.length ?? 0;
  const highAlerts = alerts?.filter((a: any) => a.status === "HIGH").length ?? 0;
  const lowAlerts = alerts?.filter((a: any) => a.status === "LOW").length ?? 0;

  const alertsByZone: Record<string, number> = {};
  alerts?.forEach((a: any) => {
    alertsByZone[a.zoneName] = (alertsByZone[a.zoneName] ?? 0) + 1;
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Intelligence</h1>
        <h2 className="font-mono text-2xl font-bold">Analytics</h2>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatBlock label="Total Zones" value={zonesLoading ? "—" : totalZones} />
        <StatBlock label="Active Alerts" value={alertsLoading ? "—" : totalAlerts} color={totalAlerts > 0 ? "text-yellow-400" : "text-foreground"} />
        <StatBlock label="High Alerts" value={alertsLoading ? "—" : highAlerts} color={highAlerts > 0 ? "text-yellow-400" : "text-foreground"} />
        <StatBlock label="Low Alerts" value={alertsLoading ? "—" : lowAlerts} color={lowAlerts > 0 ? "text-red-400" : "text-foreground"} />
      </div>

      {/* Zone breakdown */}
      <div>
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-4">Zones Overview</h3>
        {zonesLoading ? (
          <div className="border border-border bg-card h-32 animate-pulse" />
        ) : zones && zones.length > 0 ? (
          <div className="border border-border bg-card divide-y divide-border">
            {zones.map((zone: any) => {
              const zoneAlerts = alertsByZone[zone.cropName] ?? 0;
              return (
                <div key={zone.id} data-testid={`analytics-zone-${zone.id}`} className="flex items-center justify-between px-5 py-4">
                  <div>
                    <div className="font-mono text-sm font-bold text-foreground">{zone.cropName}</div>
                    <div className="font-mono text-xs text-muted-foreground">{zone.location ?? "—"}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="font-mono text-xs text-muted-foreground uppercase">Alerts</div>
                      <div className={`font-mono text-sm font-bold ${zoneAlerts > 0 ? "text-yellow-400" : "text-primary"}`}>{zoneAlerts}</div>
                    </div>
                    <span className={`font-mono text-xs px-2 py-0.5 border ${zoneAlerts > 0 ? "border-yellow-400/30 text-yellow-400" : "border-primary/30 text-primary"}`}>
                      {zoneAlerts > 0 ? "ALERT" : "NOMINAL"}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="border border-dashed border-border p-8 text-center">
            <Map className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
            <p className="font-mono text-xs text-muted-foreground">No zones to analyze.</p>
          </div>
        )}
      </div>

      {/* Alert breakdown by type */}
      {alerts && alerts.length > 0 && (
        <div>
          <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-4">Alerts by Sensor Type</h3>
          <div className="border border-border bg-card divide-y divide-border">
            {Array.from(new Set(alerts.map((a: any) => a.sensorType))).map(type => {
              const Icon = SENSOR_ICONS[(type as string).toLowerCase()] ?? Activity;
              const count = alerts.filter((a: any) => a.sensorType === type).length;
              return (
                <div key={type as string} className="flex items-center justify-between px-5 py-4">
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 text-muted-foreground" />
                    <span className="font-mono text-sm uppercase tracking-wider">{type as string}</span>
                  </div>
                  <span className="font-mono text-sm font-bold text-yellow-400">{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
