import { useListNotifications, getListNotificationsQueryKey, useMarkNotificationRead } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Bell, BellOff, CheckCheck } from "lucide-react";

export default function NotificationsPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: notifications, isLoading } = useListNotifications();
  const markRead = useMarkNotificationRead();

  const handleMarkRead = (id: number) => {
    markRead.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });
      },
      onError: () => toast({ title: "Failed to mark as read", variant: "destructive" }),
    });
  };

  const unread = notifications?.filter((n: any) => !n.isRead).length ?? 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">System</h1>
          <h2 className="font-mono text-2xl font-bold">Notifications</h2>
        </div>
        {unread > 0 && (
          <div className="font-mono text-xs border border-primary/30 text-primary px-3 py-1.5">
            {unread} UNREAD
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-16 bg-card border border-border animate-pulse" />)}
        </div>
      ) : notifications && notifications.length > 0 ? (
        <div className="border border-border bg-card divide-y divide-border">
          {notifications.map((n: any) => (
            <div
              key={n.id}
              data-testid={`notification-${n.id}`}
              className={`flex items-start justify-between px-5 py-4 ${!n.isRead ? "bg-accent/10" : ""}`}
            >
              <div className="flex items-start gap-3">
                <Bell className={`w-4 h-4 mt-0.5 flex-shrink-0 ${n.isRead ? "text-muted-foreground" : "text-primary"}`} />
                <div>
                  <div className={`font-mono text-sm font-bold ${n.isRead ? "text-muted-foreground" : "text-foreground"}`}>
                    {n.title}
                  </div>
                  <div className="font-mono text-xs text-muted-foreground mt-0.5">{n.content}</div>
                  <div className="font-mono text-xs text-muted-foreground mt-1 opacity-60">
                    {new Date(n.createdAt).toLocaleString()}
                  </div>
                </div>
              </div>
              {!n.isRead && (
                <Button
                  data-testid={`button-mark-read-${n.id}`}
                  variant="ghost"
                  size="sm"
                  className="font-mono text-xs h-7 text-muted-foreground hover:text-primary flex-shrink-0"
                  onClick={() => handleMarkRead(n.id)}
                  disabled={markRead.isPending}
                >
                  <CheckCheck className="w-3 h-3" />
                </Button>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="border border-dashed border-border p-16 text-center">
          <BellOff className="w-10 h-10 text-muted-foreground mx-auto mb-4" />
          <p className="font-mono text-sm text-foreground font-bold">No notifications</p>
          <p className="font-mono text-xs text-muted-foreground mt-1">System notifications will appear here.</p>
        </div>
      )}
    </div>
  );
}
