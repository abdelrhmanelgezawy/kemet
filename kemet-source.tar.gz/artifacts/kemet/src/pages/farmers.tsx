import {
  useListFarmers, getListFarmersQueryKey,
  useListFarmerRequests, getListFarmerRequestsQueryKey,
  useApproveFarmerRequest, useRejectFarmerRequest,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Users, CheckCircle, XCircle, Clock, UserCheck } from "lucide-react";

export default function FarmersPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: farmers, isLoading: farmersLoading } = useListFarmers();
  const { data: requests, isLoading: requestsLoading } = useListFarmerRequests();

  const approve = useApproveFarmerRequest();
  const reject = useRejectFarmerRequest();

  const handleApprove = (id: number) => {
    approve.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Request approved" });
        queryClient.invalidateQueries({ queryKey: getListFarmerRequestsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListFarmersQueryKey() });
      },
      onError: () => toast({ title: "Failed to approve", variant: "destructive" }),
    });
  };

  const handleReject = (id: number) => {
    reject.mutate({ id, data: { reason: "Declined by owner" } }, {
      onSuccess: () => {
        toast({ title: "Request rejected" });
        queryClient.invalidateQueries({ queryKey: getListFarmerRequestsQueryKey() });
      },
      onError: () => toast({ title: "Failed to reject", variant: "destructive" }),
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Team</h1>
        <h2 className="font-mono text-2xl font-bold">Farmers</h2>
      </div>

      {/* Pending Requests */}
      <div>
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
          <Clock className="w-3 h-3" /> Pending Requests
        </h3>
        {requestsLoading ? (
          <div className="border border-border bg-card h-24 animate-pulse" />
        ) : requests && requests.length > 0 ? (
          <div className="border border-border bg-card divide-y divide-border">
            {requests.map((req: any) => (
              <div key={req.id} data-testid={`request-row-${req.id}`} className="flex items-center justify-between px-5 py-4">
                <div>
                  <div className="font-mono text-sm font-bold text-foreground">{req.farmer?.name ?? `Farmer #${req.farmerId}`}</div>
                  <div className="font-mono text-xs text-muted-foreground">{req.farmer?.email ?? "—"}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    data-testid={`button-approve-${req.id}`}
                    variant="outline"
                    size="sm"
                    className="font-mono text-xs rounded-none h-7 border-primary/30 text-primary hover:bg-primary/10"
                    onClick={() => handleApprove(req.id)}
                    disabled={approve.isPending}
                  >
                    <CheckCircle className="w-3 h-3 mr-1" /> Approve
                  </Button>
                  <Button
                    data-testid={`button-reject-${req.id}`}
                    variant="outline"
                    size="sm"
                    className="font-mono text-xs rounded-none h-7 border-red-400/30 text-red-400 hover:bg-red-400/10"
                    onClick={() => handleReject(req.id)}
                    disabled={reject.isPending}
                  >
                    <XCircle className="w-3 h-3 mr-1" /> Reject
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="border border-dashed border-border p-8 text-center">
            <Clock className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
            <p className="font-mono text-xs text-muted-foreground">No pending requests.</p>
          </div>
        )}
      </div>

      {/* Managed Farmers */}
      <div>
        <h3 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-2">
          <UserCheck className="w-3 h-3" /> Managed Farmers
        </h3>
        {farmersLoading ? (
          <div className="border border-border bg-card h-24 animate-pulse" />
        ) : farmers && farmers.length > 0 ? (
          <div className="border border-border bg-card divide-y divide-border">
            {farmers.map((farmer: any) => (
              <div key={farmer.id} data-testid={`farmer-row-${farmer.id}`} className="flex items-center justify-between px-5 py-4">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 border border-border flex items-center justify-center">
                    <Users className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="font-mono text-sm font-bold text-foreground">{farmer.name}</div>
                    <div className="font-mono text-xs text-muted-foreground">{farmer.email}</div>
                  </div>
                </div>
                <span className="font-mono text-xs px-2 py-0.5 border border-primary/30 text-primary">
                  {farmer.status?.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <div className="border border-dashed border-border p-8 text-center">
            <Users className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
            <p className="font-mono text-xs text-muted-foreground">No farmers assigned yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
