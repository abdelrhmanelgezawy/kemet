import { useState } from "react";
import { useLocation } from "wouter";
import { useListZones, useCreateZone, getListZonesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Map, Search, Sprout } from "lucide-react";

function CreateZoneDialog({ onCreated }: { onCreated: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ cropName: "", location: "", iconCode: "", cropProfile: {}, mode: {} });
  const createZone = useCreateZone();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createZone.mutate({ data: form }, {
      onSuccess: () => {
        toast({ title: "Zone created" });
        setOpen(false);
        setForm({ cropName: "", location: "", iconCode: "", cropProfile: {}, mode: {} });
        onCreated();
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err?.data?.error ?? "Failed to create zone", variant: "destructive" });
      },
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button data-testid="button-create-zone" className="font-mono uppercase tracking-wider rounded-none text-xs">
          <Plus className="w-4 h-4 mr-2" /> New Zone
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-border rounded-none max-w-md">
        <DialogHeader>
          <DialogTitle className="font-mono text-sm uppercase tracking-wider">Create Zone</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-2">
          <div>
            <Label className="font-mono text-xs text-muted-foreground uppercase">Crop Name</Label>
            <Input
              data-testid="input-crop-name"
              value={form.cropName}
              onChange={e => setForm(f => ({ ...f, cropName: e.target.value }))}
              required
              className="mt-1 font-mono rounded-none border-border bg-input"
            />
          </div>
          <div>
            <Label className="font-mono text-xs text-muted-foreground uppercase">Location</Label>
            <Input
              data-testid="input-location"
              value={form.location}
              onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
              className="mt-1 font-mono rounded-none border-border bg-input"
            />
          </div>
          <div>
            <Label className="font-mono text-xs text-muted-foreground uppercase">Icon Code (optional)</Label>
            <Input
              data-testid="input-icon-code"
              value={form.iconCode}
              onChange={e => setForm(f => ({ ...f, iconCode: e.target.value }))}
              className="mt-1 font-mono rounded-none border-border bg-input"
            />
          </div>
          <Button
            data-testid="button-submit-zone"
            type="submit"
            className="w-full font-mono uppercase tracking-wider rounded-none"
            disabled={createZone.isPending}
          >
            {createZone.isPending ? "Creating..." : "Create Zone"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function ZonesPage() {
  const [search, setSearch] = useState("");
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: zones, isLoading } = useListZones();

  const filtered = zones?.filter(z =>
    z.cropName.toLowerCase().includes(search.toLowerCase()) ||
    (z.location ?? "").toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-mono text-xs text-muted-foreground uppercase tracking-wider mb-1">Management</h1>
          <h2 className="font-mono text-2xl font-bold text-foreground">Zones</h2>
        </div>
        <CreateZoneDialog onCreated={() => queryClient.invalidateQueries({ queryKey: getListZonesQueryKey() })} />
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          data-testid="input-search"
          placeholder="Search zones..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pl-9 font-mono rounded-none border-border bg-input"
        />
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="border border-border bg-card h-20 animate-pulse" />)}
        </div>
      ) : filtered.length > 0 ? (
        <div className="border border-border bg-card divide-y divide-border">
          {filtered.map(zone => (
            <div
              key={zone.id}
              data-testid={`row-zone-${zone.id}`}
              onClick={() => setLocation(`/zones/${zone.id}`)}
              className="flex items-center justify-between px-5 py-4 cursor-pointer hover:bg-accent/20 transition-colors group"
            >
              <div className="flex items-center gap-4">
                <div className="w-8 h-8 border border-border flex items-center justify-center">
                  <Sprout className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="font-mono text-sm font-bold text-foreground group-hover:text-primary transition-colors">
                    {zone.cropName}
                  </div>
                  <div className="font-mono text-xs text-muted-foreground">{zone.location ?? "—"}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Map className="w-4 h-4 text-muted-foreground" />
                <span className="font-mono text-xs text-muted-foreground">ID {zone.id}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="border border-dashed border-border p-12 text-center">
          <Sprout className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
          <p className="font-mono text-sm text-muted-foreground">
            {search ? "No zones match your search." : "No zones yet. Create your first zone."}
          </p>
        </div>
      )}
    </div>
  );
}
