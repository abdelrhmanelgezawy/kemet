import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useLogout, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { Activity, Bell, Cpu, LayoutDashboard, Map, Users, LogOut } from "lucide-react";
import { useEffect } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const logout = useLogout();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isLoading && !user) {
      setLocation("/login");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Activity className="w-8 h-8 text-primary animate-pulse" />
      </div>
    );
  }

  if (!user) return null;

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.setQueryData(getGetMeQueryKey(), null);
        setLocation("/login");
      }
    });
  };

  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/zones", label: "Zones", icon: Map },
    { href: "/alerts", label: "Alerts", icon: Activity },
    { href: "/analytics", label: "Analytics", icon: Cpu },
    { href: "/farmers", label: "Farmers", icon: Users },
    { href: "/notifications", label: "Notifications", icon: Bell },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col md:flex-row text-foreground dark">
      {/* Sidebar */}
      <aside className="w-full md:w-64 border-r border-border bg-sidebar flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <div className="font-mono text-primary font-bold tracking-widest text-lg uppercase flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Kemet Command
          </div>
        </div>
        
        <nav className="flex-1 py-4 px-3 space-y-1">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="flex items-center gap-3 px-3 py-2.5 rounded-none text-sm font-mono text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors group">
              <item.icon className="w-4 h-4 group-hover:text-primary transition-colors" />
              <span>{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-border">
          <div className="mb-4">
            <div className="text-xs text-muted-foreground font-mono uppercase mb-1">Operator</div>
            <Link href="/profile" className="font-mono text-sm hover:text-primary transition-colors block">
              {user.name}
            </Link>
          </div>
          <Button variant="outline" className="w-full justify-start font-mono text-xs rounded-none border-border hover:border-primary hover:text-primary" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            DISCONNECT
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-background/50">
        <div className="p-6 md:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}
