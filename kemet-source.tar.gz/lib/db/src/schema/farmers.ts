import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const zoneAssignmentsTable = pgTable("zone_assignments", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id").notNull(),
  zoneId: integer("zone_id").notNull(),
  assignedAt: timestamp("assigned_at", { withTimezone: true }).notNull().defaultNow(),
});

export const farmerRequestsTable = pgTable("farmer_requests", {
  id: serial("id").primaryKey(),
  farmerId: integer("farmer_id").notNull(),
  ownerId: integer("owner_id").notNull(),
  status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
  rejectionReason: text("rejection_reason"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  respondedAt: timestamp("responded_at", { withTimezone: true }),
});

export const insertZoneAssignmentSchema = createInsertSchema(zoneAssignmentsTable).omit({ id: true });
export type InsertZoneAssignment = z.infer<typeof insertZoneAssignmentSchema>;
export type ZoneAssignment = typeof zoneAssignmentsTable.$inferSelect;

export const insertFarmerRequestSchema = createInsertSchema(farmerRequestsTable).omit({ id: true, createdAt: true });
export type InsertFarmerRequest = z.infer<typeof insertFarmerRequestSchema>;
export type FarmerRequest = typeof farmerRequestsTable.$inferSelect;
