import { pgTable, serial, integer, text, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const alertsTable = pgTable("alerts", {
  id: serial("id").primaryKey(),
  zoneId: integer("zone_id").notNull(),
  zoneName: text("zone_name").notNull(),
  sensorType: text("sensor_type").notNull(),
  value: numeric("value", { precision: 10, scale: 2 }).notNull(),
  minThreshold: numeric("min_threshold", { precision: 10, scale: 2 }),
  maxThreshold: numeric("max_threshold", { precision: 10, scale: 2 }),
  status: text("status", { enum: ["LOW", "HIGH"] }).notNull(),
  isResolved: boolean("is_resolved").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  resolvedAt: timestamp("resolved_at", { withTimezone: true }),
});

export const insertAlertSchema = createInsertSchema(alertsTable).omit({ id: true, createdAt: true });
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alertsTable.$inferSelect;
