import { pgTable, serial, integer, text, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sensorsTable = pgTable("sensors", {
  id: serial("id").primaryKey(),
  zoneId: integer("zone_id").notNull(),
  sensorType: text("sensor_type").notNull(),
  value: numeric("value", { precision: 10, scale: 2 }).notNull(),
  status: text("status", { enum: ["NORMAL", "LOW", "HIGH"] }).notNull().default("NORMAL"),
  lastUpdate: timestamp("last_update", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sensorLogsTable = pgTable("sensor_logs", {
  id: serial("id").primaryKey(),
  zoneId: integer("zone_id").notNull(),
  sensorType: text("sensor_type").notNull(),
  value: numeric("value", { precision: 10, scale: 2 }).notNull(),
  timestamp: timestamp("timestamp", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSensorSchema = createInsertSchema(sensorsTable).omit({ id: true, createdAt: true });
export type InsertSensor = z.infer<typeof insertSensorSchema>;
export type Sensor = typeof sensorsTable.$inferSelect;

export const insertSensorLogSchema = createInsertSchema(sensorLogsTable).omit({ id: true });
export type InsertSensorLog = z.infer<typeof insertSensorLogSchema>;
export type SensorLog = typeof sensorLogsTable.$inferSelect;
